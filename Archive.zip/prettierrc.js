module.exports = {
    singleQuote: true,
    trailingComma: 'all',
    rules: { 'prettier/prettier': ['error', prettierConfig] },
};
