export class UserDto {
  id: number;
  name: string;
  lastName: string;
  fiscalCode: string;
  phone: string;
  province: string;
  email: string;
  created_at: string;
  updated_at: string;
  deleted_at: string;
}
