export class CreateUserDto {
   name: string;
   lastName: string;
   fiscalCode: string;
   phone: string;
   province: string;
   email: string;
   password: string;
}
