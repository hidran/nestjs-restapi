export class UpdateUserDto {
  readonly name?: string;
  readonly lastName?: string;
  readonly fiscalCode?: string;
  readonly phone?: string;
  readonly province?: string;
  readonly email?: string;
}
